import React, { Component } from 'react'

export class Cart extends Component {

    constructor(props) {
        super(props)
    
        this.state = {
             cart:this.props.location.cartDetails || []
        }
    }

    removeFromCart = data => {
        let cart = this.state.cart
        let updatedCart = cart.filter(function(product) { return product.productId != data.productId });

        this.setState({
            cart:updatedCart
        })
    }
    

    render() {
        return (
            <div>
                <nav class="navbar navbar-light bg-dark">
                    <span style={{fontStyle:'italic',color:'white',fontWeight:'bold'}}>Cart &nbsp;
                    {this.state.cart.length> 0 && <span class="badge badge-danger">{this.state.cart.length}</span> }
                    </span>
                </nav>
                 <div style={{display:'flex',marginTop:'30px'}} >
                    {this.state.cart.length === 0 && 
                        <div style={{ 
                            display: "inline-block",
                            position: 'fixed',
                            top: '20%',
                            bottom: 0,
                            left: 0,
                            right: 0,
                        }} 
                        >
                            <h3 className='App' style={{fontStyle:'italic'}} >Your cart is empty!!</h3>
                            <h6 className='App' style={{fontStyle:'italic'}} >Visit <a href='/products'>Products</a> page to explore more..</h6>
                        </div>
                    }
                    {this.state.cart.map(data =>{
                        return(
                            <div class="card" style={{width:'250px',marginRight:'13px'}} >
                                <img src={data.image} class="card-img-top" alt="..."/>
                                <div class="card-body">
                                <h5 class="card-title" style={{fontFamily:'monospace'}} >{data.productName}</h5>
                                <div style={{display:'flex'}} >
                                    <p style={{fontStyle:'italic',fontWeight:'bold'}} >Price : </p> &nbsp;
                                    <p class="card-text">{data.price} /-</p>
                                </div>
                                    <div style={{float:'right'}} >
                                        <button style={{fontSize:'13px'}} className='btn btn-danger' onClick={() => this.removeFromCart(data)} >Remove</button> 
                                    </div>
                                </div>
                            </div>
                        )
                    })}
                </div>
                {
                        this.state.cart.length > 0 && 
                        <div style={{float:'right',margin:'10px'}}>
                            <button className='btn btn-secondary' onClick={() => window.location.href='/products'} >Back to products</button>&nbsp;
                            <button className='btn btn-success'>Check out</button> 
                        </div>
                    }
            </div>
        )
    }
}

export default Cart
