import React, { Component } from 'react'

export class login extends Component {

    constructor(props) {
        super(props)
    
        this.state = {
             errorMsg:'Please enter a valid details.',
             showErrorMsg:false
        }
    }    
    

    handleChange = e => {
        const {name , value} = e.target

        this.setState({
            [name] : value
        })
    }

    handleSubmit = e => {
        if(this.state.username==='wagdy' && this.state.password==='123'){
            this.setState({
                showErrorMsg:false
            })
            window.location.href='/products'
        }else{
            this.setState({
                showErrorMsg:true
            })
        }
    }

    render() {
        return (
            <div>
                <nav class="navbar navbar-light bg-dark">
                    <span style={{fontStyle:'italic',color:'white',fontWeight:'bold'}}>Login</span>
                </nav>
                <div class="form" style={{display:'inline-block',position:'fixed',width:'30%',margin:'auto',top:'25%',left:'35%',padding:'10px'}} >
                    <div class="form-group" >
                        <label style={{fontStyle:'italic',fontWeight:'bold'}} >Username</label>
                        <input type="text" name='username' autocomplete="off" onChange={this.handleChange} class="form-control rounded" />
                    </div>
                    <div class="form-group">
                        <label style={{fontStyle:'italic',fontWeight:'bold'}} >Password</label>
                        <input type="password" name='password' onChange={this.handleChange} class="form-control rounded" />
                    </div>
                    {this.state.showErrorMsg && <p style={{fontStyle:'italic',color:'red'}} >
                        {this.state.errorMsg}
                    </p>}
                    <div style={{float:'right'}}  >
                        <button class='btn btn-primary' type='submit' onClick={this.handleSubmit} >Login</button>
                    </div>
                </div>
            </div>
        )
    }
}

export default login
