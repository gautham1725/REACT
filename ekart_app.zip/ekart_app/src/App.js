import React from 'react';
import './App.css';
import Login from './login';
import Routing from './Routing';

function App() {
  return (
    <div>
      <Routing/>
    </div>
  );
}

export default App;
