import React, { Component } from 'react'
import ProductList from './data/products.json'
import { Route } from 'react-router'
import { Link } from 'react-router-dom'

export class products extends Component {
    
    constructor(props) {
        super(props)
    
        this.state = {
             cart:[]
        }
    }

    handleCart = (data) => {
        this.setState({
            cart:[...this.state.cart,data]
        })
    }

    removeFromCart = data => {
        let cart = this.state.cart
        let updatedCart = cart.filter(function(product) { return product.productId != data.productId });

        this.setState({
            cart:updatedCart
        })
    }
    
    render() {
        return (
            <div>
                 <nav class="navbar navbar-light bg-dark">
                    <span style={{fontStyle:'italic',color:'white',fontWeight:'bold'}}>Products</span>
                </nav>
                <div style={{display:'flex',marginTop:'30px'}} >
                {ProductList.map(data =>{
                    return(
                        <div class="card" style={{width:'250px',marginRight:'13px'}} >
                            <img src={data.image} class="card-img-top" alt="..."/>
                            <div class="card-body">
                                <h5 class="card-title" style={{fontFamily:'monospace'}} >{data.productName}</h5>
                                <div style={{display:'flex'}} >
                                    <p style={{fontStyle:'italic',fontWeight:'bold'}} >Price : </p> &nbsp;
                                    <p class="card-text">{data.price} /-</p>
                                </div>
                                <div style={{display:'flex'}} >
                                    {!this.state.cart.includes(data) 
                                    ? 
                                    <div>
                                        <button style={{fontSize:'13px'}} className='btn btn-primary' onClick={() => this.handleCart(data)} >Add to Cart</button> &nbsp;
                                    </div>
                                    :
                                    <div>
                                        <button style={{fontSize:'13px'}} className='btn btn-danger' onClick={() => this.removeFromCart(data)} >Remove</button> &nbsp; 
                                    </div>
                                }
                                    <button style={{fontSize:'13px'}} className='btn btn-secondary' >More details</button>
                                </div>
                            </div>
                        </div>
                    )
                })}
                </div>
                <div style={{float:'right',margin:'10px'}}>
                    <Link className='btn btn-success' to={{ pathname: '/cart', cartDetails: this.state.cart}}>Go to Cart &nbsp;
                        {this.state.cart.length> 0 && <span class="badge badge-danger">{this.state.cart.length}</span> }
                     </Link>
                </div>
            </div>
        )
    }
}

export default products