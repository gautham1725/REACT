import React, { Component } from 'react'
import { BrowserRouter as Router , Route  , Switch } from 'react-router-dom'
import Login from './login.js'
import Products from './products'
import Cart from './Cart'

export class Routing extends Component {

    render() {  
        return (
            <div>
                <Router>
                    <Switch>
                        <Route exact path="/"><Login/></Route>
                        <Route exact path="/login" component={Login} />
                        <Route exact path="/products" component={Products} />
                        <Route exact path="/cart/:name" component={Cart} />
                        <Route exact path="/cart" component={Cart} />
                    </Switch>
                </Router>
            </div>
        )
    }
}

export default Routing