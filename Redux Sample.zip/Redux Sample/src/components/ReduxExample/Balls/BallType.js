export const BUY_BALL = 'BUY_BALL'
export const ADD_BALL = 'ADD_BALL'