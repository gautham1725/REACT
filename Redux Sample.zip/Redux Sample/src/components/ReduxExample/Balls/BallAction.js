import { BUY_BALL, ADD_BALL } from "./BallType"

export const buyBall = () => {
    return {
        type : BUY_BALL,
        
    }
}

export const addBall =  () => {
    return{
        type : ADD_BALL
    }
}