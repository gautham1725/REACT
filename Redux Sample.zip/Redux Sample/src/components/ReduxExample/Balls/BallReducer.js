import { BUY_BALL, ADD_BALL } from "./BallType"


export const initialState = {
    numberOfBalls : 20,
}

export const ballReducer = (state = initialState , action) => {

    switch(action.type){
        
        case BUY_BALL : 
        return {
            ...state,
            numberOfBalls : state.numberOfBalls - 1,
        }

        case ADD_BALL : return {
            
            ...state,
            numberOfBalls : state.numberOfBalls + 1
        }


        default :
            return state
    }
}