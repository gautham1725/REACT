import {combineReducers} from 'redux'
import { ballReducer } from './Balls/BallReducer'
import { batReducer } from './Bats/BatReducer'

export const rootReducer = combineReducers({
    ball : ballReducer,
    bat : batReducer
})