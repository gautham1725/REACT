export const BUY_BAT = 'BUY_BAT'
export const ADD_BAT = 'ADD_BAT'