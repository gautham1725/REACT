import { BUY_BAT, ADD_BAT } from "./BatType"

const initialState = {
    numberOfBats : 10
}

export const batReducer = (state = initialState,action) => {
    switch(action.type){
        case BUY_BAT : return {
            ...state,
            numberOfBats : state.numberOfBats - 1
        }

        case ADD_BAT : return {
            ...state,
            numberOfBats : state.numberOfBats + 1
        }

        default :
            return state
    }
}