import { ADD_BAT, BUY_BAT } from "./BatType"

export const buyBat = () => {
    return {
        type : BUY_BAT
    }
}

export const addBat = () => {
    return {
        type : ADD_BAT
    }
}