import React from 'react'
import { useSelector , useDispatch } from 'react-redux'
import { buyBall } from '../ReduxExample'
import { addBall } from '../ReduxExample'

function HooksBallContainer() {
    const numOfBalls =  useSelector( state => state.ball.numberOfBalls )
    const dispatch = useDispatch()
    return (
        <div>
            <h1>Number of Balls : {numOfBalls}</h1>
            <button onClick={ () => dispatch( buyBall() )} >Buy Ball</button><br/>
            <button onClick={ () => dispatch( addBall() )} >Add Ball</button>
        </div>
    )
}

export default HooksBallContainer