import React from 'react'
import {buyBall, addBall} from '../ReduxExample'
import {connect} from 'react-redux'

function BallContainer(props) {
    return (
        <div>
            <h1>Number of Balls : {props.numberOfBalls}</h1>
            <button onClick={props.buyBall} >Buy Ball</button><br/>
            <button onClick={props.addBall} >Add Ball</button>
        </div>
    )
}

const mapStateToProps = state => {
    return state
}

const mapDispatchToProps = dispatch => {
    return {
        buyBall : () => dispatch(buyBall()),
        addBall:()=> dispatch(addBall())

    }
}

export default connect(mapStateToProps,mapDispatchToProps)(BallContainer)