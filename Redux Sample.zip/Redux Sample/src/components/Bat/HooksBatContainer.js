import React from 'react'
import { buyBat, addBat } from '../ReduxExample'
import { useSelector,useDispatch } from 'react-redux'

function HooksBatContainer() {
    const numberOfBats = useSelector(state => state.bat.numberOfBats)
    const dispatch = useDispatch()
    return (
        <div>
            <h1>Number of Bats : {numberOfBats}</h1>
            <button onClick={ () => dispatch( buyBat() ) } >Buy Bat</button><br/>
            <button onClick={ () => dispatch( addBat() ) } >Add Bat</button>
        </div>
    )
}

export default HooksBatContainer